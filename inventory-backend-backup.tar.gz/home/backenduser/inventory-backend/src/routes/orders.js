const express = require('express');
const db = require('../config/db');

const router = express.Router();

// Hent alle ordre
router.get('/', async (req, res) => {
  try {
    const [orders] = await db.query('SELECT * FROM orders');
    res.json(orders);
  } catch (error) {
    console.error('Error fetching orders:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Opprett ny ordre
router.post('/', async (req, res) => {
  const { customer_name, store, status } = req.body;
  try {
    const [result] = await db.query(
      'INSERT INTO orders (customer_name, store, status) VALUES (?, ?, ?)',
      [customer_name, store, status || 'pending']
    );
    res.json({ id: result.insertId, customer_name, store, status });
  } catch (error) {
    console.error('Error creating order:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Oppdater ordrestatus
router.put('/:id', async (req, res) => {
  const { status } = req.body;
  const { id } = req.params;
  try {
    await db.query('UPDATE orders SET status = ? WHERE id = ?', [status, id]);
    res.json({ message: 'Order updated' });
  } catch (error) {
    console.error('Error updating order:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

// Slett ordre
router.delete('/:id', async (req, res) => {
  const { id } = req.params;
  try {
    await db.query('DELETE FROM orders WHERE id = ?', [id]);
    res.json({ message: 'Order deleted' });
  } catch (error) {
    console.error('Error deleting order:', error);
    res.status(500).json({ error: 'Server error' });
  }
});

module.exports = router;

